import { DraggableChat } from "./components/DraggableChat";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-zinc-100 p-8 text-slate-800">
      <main className="mx-auto max-w-3xl space-y-8 pt-12">
        <div className="space-y-4 text-center">
          <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 shadow-lg shadow-indigo-200">
            <svg
              className="h-8 w-8 text-white"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="2" y="4" width="20" height="16" rx="2" />
              <path d="M10 4v4" />
              <path d="M2 8h20" />
              <path d="M6 4v4" />
            </svg>
          </div>
          <h1 className="text-3xl font-semibold tracking-tight text-slate-900">
            Draggable Chat Widget Template
          </h1>
          <p className="text-slate-500">
            A reusable React component with boundary constraints, localStorage persistence, and mobile touch support.
          </p>
        </div>

        <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="mb-4 text-lg font-semibold text-slate-900">Features</h2>
          <ul className="grid gap-3 text-slate-600 sm:grid-cols-2">
            <Feature text="Pointer-event dragging with setPointerCapture" />
            <Feature text="Drag handle so body content stays interactive" />
            <Feature text="Viewport boundary constraints" />
            <Feature text="Position & open state persisted to localStorage" />
            <Feature text="Keyboard nudge + Escape to close" />
            <Feature text="Mobile-friendly touch-action: none" />
          </ul>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="mb-4 text-lg font-semibold text-slate-900">Usage</h2>
          <pre className="overflow-x-auto rounded-xl bg-slate-900 p-4 text-sm text-slate-100">
            <code>{`<DraggableChat
  storageKey="support-chat"
  defaultPosition={{ x: 24, y: 24 }}
  defaultOpen={true}
/>`}</code>
          </pre>
        </section>
      </main>

      <DraggableChat
        storageKey="demo-chat"
        defaultPosition={{ x: 24, y: 24 }}
        defaultOpen={true}
      />
    </div>
  );
}

function Feature({ text }: { text: string }) {
  return (
    <li className="flex items-start gap-3">
      <span className="mt-1 inline-block h-2 w-2 shrink-0 rounded-full bg-indigo-500" />
      <span>{text}</span>
    </li>
  );
}
