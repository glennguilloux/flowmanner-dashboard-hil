import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { cn } from "../utils/cn";

export interface DraggableChatProps {
  /** Unique id used to persist this widget's position in localStorage. */
  storageKey?: string;
  /** Default position on first load. */
  defaultPosition?: { x: number; y: number };
  /** Whether the widget is open by default. */
  defaultOpen?: boolean;
}

type Position = { x: number; y: number };

const STORAGE_KEY_PREFIX = "draggable-chat";

export function DraggableChat({
  storageKey = "default",
  defaultPosition = { x: 24, y: 24 },
  defaultOpen = true,
}: DraggableChatProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const [position, setPosition] = useState<Position>(defaultPosition);
  const [mounted, setMounted] = useState(false);

  const widgetRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef({
    active: false,
    startX: 0,
    startY: 0,
    initialX: 0,
    initialY: 0,
  });

  // Load persisted state.
  useEffect(() => {
    setMounted(true);
    try {
      const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}:${storageKey}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.x === "number" && typeof parsed.y === "number") {
          setPosition({ x: parsed.x, y: parsed.y });
        }
        if (typeof parsed.open === "boolean") {
          setIsOpen(parsed.open);
        }
      }
    } catch {
      // Ignore storage errors.
    }
  }, [storageKey]);

  // Persist state whenever it changes.
  useEffect(() => {
    if (!mounted) return;
    try {
      localStorage.setItem(
        `${STORAGE_KEY_PREFIX}:${storageKey}`,
        JSON.stringify({ x: position.x, y: position.y, open: isOpen })
      );
    } catch {
      // Ignore storage errors.
    }
  }, [position, isOpen, storageKey, mounted]);

  // Clamp the widget inside the viewport.
  const clampPosition = (x: number, y: number): Position => {
    const widget = widgetRef.current;
    const width = widget?.offsetWidth ?? 360;
    const height = widget?.offsetHeight ?? 480;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    return {
      x: Math.min(Math.max(x, 0), Math.max(vw - width, 0)),
      y: Math.min(Math.max(y, 0), Math.max(vh - height, 0)),
    };
  };

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return; // Only left click / primary pointer.
    const target = e.currentTarget;
    target.setPointerCapture(e.pointerId);

    dragRef.current = {
      active: true,
      startX: e.clientX,
      startY: e.clientY,
      initialX: position.x,
      initialY: position.y,
    };

    target.style.cursor = "grabbing";
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active) return;

    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;

    setPosition(
      clampPosition(dragRef.current.initialX + dx, dragRef.current.initialY + dy)
    );
  };

  const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active) return;
    dragRef.current.active = false;
    e.currentTarget.releasePointerCapture(e.pointerId);
    e.currentTarget.style.cursor = "grab";
  };

  // Keep widget in bounds when window resizes.
  useLayoutEffect(() => {
    const handleResize = () => {
      setPosition((prev) => clampPosition(prev.x, prev.y));
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Keyboard nudge support for accessibility.
  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    const step = e.shiftKey ? 20 : 4;
    let dx = 0;
    let dy = 0;

    switch (e.key) {
      case "ArrowUp":
        dy = -step;
        break;
      case "ArrowDown":
        dy = step;
        break;
      case "ArrowLeft":
        dx = -step;
        break;
      case "ArrowRight":
        dx = step;
        break;
      case "Escape":
        setIsOpen(false);
        return;
      default:
        return;
    }

    e.preventDefault();
    setPosition((prev) => clampPosition(prev.x + dx, prev.y + dy));
  };

  const resetPosition = () => {
    setPosition(clampPosition(defaultPosition.x, defaultPosition.y));
  };

  return (
    <>
      {/* Floating toggle button shown when chat is closed */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className={cn(
            "fixed z-[9998] flex h-14 w-14 items-center justify-center rounded-full",
            "bg-indigo-600 text-white shadow-lg shadow-indigo-200 transition-transform",
            "hover:scale-105 active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
          )}
          style={{
            left: position.x,
            top: position.y,
          }}
          aria-label="Open chat"
        >
          <ChatBubbleIcon className="h-6 w-6" />
        </button>
      )}

      {isOpen && (
        <div
          ref={widgetRef}
          className={cn(
            "fixed z-[9999] flex w-[min(92vw,360px)] flex-col overflow-hidden rounded-2xl",
            "border border-slate-200 bg-white shadow-2xl shadow-slate-300/50",
            "transition-opacity duration-200"
          )}
          style={{
            left: position.x,
            top: position.y,
          }}
          role="dialog"
          aria-label="Draggable chat"
          aria-modal="true"
        >
          {/* Drag handle */}
          <div
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            onKeyDown={handleKeyDown}
            tabIndex={0}
            className={cn(
              "flex cursor-grab select-none items-center justify-between",
              "border-b border-slate-100 bg-slate-50 px-4 py-3",
              "touch-none active:cursor-grabbing",
              "focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-indigo-400"
            )}
            aria-grabbed={dragRef.current.active}
            title="Drag to move, arrow keys to nudge"
          >
            <div className="flex items-center gap-2">
              <DragHandleIcon className="h-4 w-4 text-slate-400" />
              <span className="text-sm font-semibold text-slate-700">Chat</span>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={resetPosition}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
                aria-label="Reset position"
                title="Reset position"
              >
                <ResetIcon className="h-4 w-4" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
                aria-label="Close chat"
              >
                <CloseIcon className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Chat body */}
          <div className="flex h-[min(70vh,480px)] flex-col">
            <div className="flex-1 space-y-3 overflow-y-auto p-4">
              <Message
                role="assistant"
                text="Hi there! This is a draggable chat widget. Grab the header to move it around."
              />
              <Message
                role="user"
                text="Can I use this on mobile too?"
              />
              <Message
                role="assistant"
                text="Yes — it uses pointer events with touch-action: none on the handle, so it works on touch devices."
              />
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const input = e.currentTarget.elements.namedItem("message") as HTMLInputElement;
                if (input.value.trim()) {
                  // In a real app, send the message here.
                  input.value = "";
                }
              }}
              className="border-t border-slate-100 p-3"
            >
              <div className="flex gap-2">
                <input
                  name="message"
                  type="text"
                  placeholder="Type a message…"
                  className={cn(
                    "min-w-0 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm",
                    "text-slate-800 placeholder:text-slate-400",
                    "focus:border-indigo-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-100"
                  )}
                  autoComplete="off"
                />
                <button
                  type="submit"
                  className={cn(
                    "rounded-xl bg-indigo-600 px-3 py-2 text-sm font-medium text-white",
                    "hover:bg-indigo-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400",
                    "active:scale-95"
                  )}
                >
                  Send
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

function Message({ role, text }: { role: "user" | "assistant"; text: string }) {
  const isUser = role === "user";
  return (
    <div className={cn("flex", isUser ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[80%] rounded-2xl px-3.5 py-2 text-sm leading-relaxed",
          isUser
            ? "rounded-br-md bg-indigo-600 text-white"
            : "rounded-bl-md bg-slate-100 text-slate-700"
        )}
      >
        {text}
      </div>
    </div>
  );
}

function ChatBubbleIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}

function DragHandleIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
    >
      <circle cx="9" cy="6" r="1.5" />
      <circle cx="9" cy="12" r="1.5" />
      <circle cx="9" cy="18" r="1.5" />
      <circle cx="15" cy="6" r="1.5" />
      <circle cx="15" cy="12" r="1.5" />
      <circle cx="15" cy="18" r="1.5" />
    </svg>
  );
}

function CloseIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M18 6 6 18" />
      <path d="M6 6l12 12" />
    </svg>
  );
}

function ResetIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
      <path d="M3 3v5h5" />
    </svg>
  );
}
